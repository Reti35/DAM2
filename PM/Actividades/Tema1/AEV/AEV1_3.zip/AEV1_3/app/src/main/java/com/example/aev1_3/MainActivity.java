package com.example.aev1_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcularEdadPerro(View v){

        TextView tv = findViewById(R.id.txtEdadPerro);
        EditText et = findViewById(R.id.txtEdadHumana);

        double edadHumana = Integer.valueOf(String.valueOf(et.getText()));

        double primerosAños = 2;
        double edadPerro = 0;

        if (edadHumana > 2){

            double restoAños = edadHumana - primerosAños;

            primerosAños = 21;

            restoAños = restoAños * 4;

            edadPerro = primerosAños + restoAños;

        } else if(edadHumana == 2){

            edadPerro = 21;

        } else {

            edadPerro = 10.5;

        }



        tv.setText(String.valueOf(edadPerro));

    }

}