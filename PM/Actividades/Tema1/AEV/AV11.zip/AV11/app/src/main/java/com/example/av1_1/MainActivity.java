package com.example.av1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcular(View v){

        EditText eth = findViewById(R.id.txtHorasSemanales);
        EditText etp = findViewById(R.id.txtPagoPorHora);
        TextView tv = findViewById(R.id.txtMostrarSalario);

        int hs = Integer.valueOf(String.valueOf(eth.getText()));
        int ph = Integer.valueOf(String.valueOf(etp.getText()));

        if (hs <= 40){

            res = hs * ph;

        }else {

            int res2 = ph * 40;

            hs = hs - 40;

            ph = (int) (ph * 1.5);

            res = (hs * ph) + res2;

        }

        tv.setText(String.valueOf(res));

    }

}