package com.example.ae_7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcular(View v){

        TextView tv = findViewById(R.id.txtResultado);
        EditText edd = findViewById(R.id.txtDinero);
        EditText edcps = findViewById(R.id.txtCPS);

        double precioCaja = Double.valueOf(String.valueOf(edd.getText()));

        int cajasPorSemana = Integer.valueOf(String.valueOf(edcps.getText()));

        double precio1Semana = precioCaja * cajasPorSemana;
        double precio2Semanas = precio1Semana * 2;
        double precio3Semanas = precio1Semana * 3;
        double precio4Semanas = precio1Semana * 4;
        double precio1Mes = precio1Semana * 5;
        double precio2Meses = precio1Mes * 2;
        double precio3Meses = precio1Mes * 3;
        double precio6Meses = precio3Meses * 2;
        double precio10Meses = precio1Mes * 10;
        double precio1Año = precio1Mes * 12;
        double precio2Años = precio1Año * 2;
        double precio5Años = precio1Año * 5;
        double precio10Años = precio1Año * 10;

        tv.setText("Precio una semana: "+ precio1Semana + "\r \nPrecio dos semanas: " +
                precio2Semanas + "\r \nPrecio tres semanas: " + precio3Semanas +
                "\r \nPrecio cuatro semanas: " + precio4Semanas + "\r \nPrecio un mes: " +
                precio1Mes + "\r \nPrecio dos meses: " + precio2Meses + "\r \nPrecio tres meses: " +
                precio3Meses + "\r \nPrecio seis meses: " + precio6Meses +
                "\r \nPrecio diez meses: " + precio10Meses + "\r \nPrecio un año: " + precio1Año +
                "\r \nPrecio dos años: " + precio2Años + "\r \nPrecio cinco años: " + precio5Años +
                "\r \nPrecio diez años: " + precio10Años);
    }

}