package com.example.av1_5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void comprobarPalindromo(View v) {

        TextView tv = findViewById(R.id.txtMostrar);
        EditText et = findViewById(R.id.txtPalindromo);

        String palindromo = String.valueOf(et.getText());

        palindromo.toLowerCase().replace("á", "a").replace("é", "e").replace("í", "i")
                .replace("ó", "o").replace("ú", "u").replace(" ", "").
                replace(".", "").replace(",", "");

        String inverso = new StringBuilder(palindromo).reverse().toString();

        if (inverso.equals(palindromo)) {

            tv.setText("Es palindromo");

        } else {

            tv.setText("No es palindromo");

        }

    }

}