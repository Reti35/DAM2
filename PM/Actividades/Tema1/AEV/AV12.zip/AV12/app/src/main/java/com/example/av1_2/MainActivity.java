package com.example.av1_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcular(View v){

        EditText et = findViewById(R.id.txtSegundos);
        TextView tv = findViewById(R.id.txtHorasMinutosSegundos);

        int segundos = Integer.valueOf(String.valueOf(et.getText()));
        int minutos = 0;
        int horas = 0;
        int dias = 0;

        if (segundos >= 60){

            while (segundos >= 60){

                minutos++;

                segundos = segundos - 60;

            }

        }

        if (minutos >= 60){

            while (minutos >= 60) {

                horas++;

                minutos = minutos - 60;

            }

        }

        if (horas >= 24){

            while (horas >= 24){

                dias++;

                horas = horas - 24;

            }

        }

        tv.setText(toString(dias, minutos, horas, segundos));

    }

    private String toString(int dias, int minutos, int horas, int segundos) {

        String tiempo = "D: " + dias + " H: " + horas + " Min: " + minutos + " Seg: " + segundos;
        return  tiempo;

    }

}