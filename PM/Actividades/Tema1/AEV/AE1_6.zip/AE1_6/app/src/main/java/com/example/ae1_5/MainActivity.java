package com.example.ae1_5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void convertir(View v){

        TextView tv = findViewById(R.id.txtResultado);
        EditText et = findViewById(R.id.txtDinero);

        double dinero = Double.valueOf(String.valueOf(et.getText()));

        int b500 = 0, b200 = 0, b100 = 0, b50 = 0, b20 = 0, b10 = 0, b5 = 0, m2 = 0, m1 = 0, c50 = 0, c20 = 0, c10 = 0,
                c5 = 0, c2 = 0, c1 = 0;

        if (dinero >= 500) {

            b500 = (int) (dinero / 500);
            dinero = dinero % 500;

        }

        if (dinero >= 200) {

            b200 = (int) (dinero / 200);
            dinero = dinero % 200;

        }

        if (dinero >= 100) {

            b100 = (int) (dinero / 100);
            dinero = dinero % 100;

        }

        if (dinero >= 50) {

            b50 = (int) (dinero / 50);
            dinero = dinero % 50;

        }

        if (dinero >= 20) {

            b20 = (int) (dinero / 20);
            dinero = dinero % 20;

        }

        if (dinero >= 10) {

            b10 = (int) (dinero / 10);
            dinero = dinero % 10;

        }

        if (dinero >= 5) {

            b5 = (int) (dinero / 5);
            dinero = dinero % 5;

        }

        if (dinero >= 2) {

            m2 = (int) (dinero / 2);
            dinero = dinero % 2;

        }

        if (dinero >= 1) {

            m1 = (int) (dinero / 1);
            dinero = dinero % 1;

        }

        if (dinero >= 0.50) {

            c50 = (int) (dinero / 0.50);
            dinero = dinero % 0.50;

        }

        if (dinero >= 0.20) {

            c20 = (int) (dinero / 0.20);
            dinero = dinero % 0.20;

        }

        if (dinero >= 0.10) {

            c10 = (int) (dinero / 0.10);
            dinero = dinero % 0.10;

        }

        if (dinero >= 0.05) {

            c5 = (int) (dinero / 0.05);
            dinero = dinero % 0.05;

        }

        if (dinero >= 0.02) {

            c2 = (int) (dinero / 0.02);
            dinero = dinero % 0.02;

        }

        if (dinero >= 0.01) {

            c1 = (int) (dinero / 0.01);
            dinero = dinero % 0.01;

        }

        tv.setText(String.valueOf("Billete/s de 500: " + b500 + "\r \nBillete/s de 200: " + b200 + "\r \nBillete/s de 100: " + b100
                + "\r \nBillete/s de 50: " + b50 + "\r\nBillete/s de 20: " + b20 + "\r \nBillete/s de 10: " + b10
                + "\r \nBillete/s de 5: " + b5 + "\r \nMoneda/s de 2: " + m2 + "\r \nMoneda/s de 1: " + m1
                + "\r \nCentimo/s de 50: " + c50 + "\r \nCentimo/s de 20: " + c20 + "\r \nCentimo/s de 10: " + c10
                + "\r \nCentimo/s de 5: " + c5 + "\r \nCentimo/s de 2: " + c2 + "\r \nCentimo/s de 1: " + c1));

    }

}