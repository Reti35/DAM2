package com.example.av1_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcularPrecio(View v) {

        TextView tv = findViewById(R.id.txtResultado);
        EditText etc = findViewById(R.id.txtTipoCarnet);
        EditText etp = findViewById(R.id.txtNumPracticas);

        String tipoCarnet = String.valueOf(etc.getText());
        int numPracticas = Integer.valueOf(String.valueOf(etp.getText()));
        int precioPracticas = 0;
        int precioMatricula = 0;
        int resultado = 0;

        switch (tipoCarnet){

            case "A":
                precioMatricula = 150;
                precioPracticas = 15 * numPracticas;
                resultado = precioMatricula + precioPracticas;
                tv.setText(String.valueOf(resultado));
                break;

            case "B":
                precioMatricula = 325;
                precioPracticas = 21 * numPracticas;
                resultado = precioMatricula + precioPracticas;
                tv.setText(String.valueOf(resultado));
                break;

            case  "C":
                precioMatricula = 520;
                precioPracticas = 36 * numPracticas;
                resultado = precioMatricula + precioPracticas;
                tv.setText(String.valueOf(resultado));
                break;

            case "D":
                precioMatricula = 610;
                precioPracticas = 50 * numPracticas;
                resultado = precioMatricula + precioPracticas;
                tv.setText(String.valueOf(resultado));
                break;

            default:
                tv.setText("Tipo de carnet incorrecto");

        }

    }

}