package com.example.ae_8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Integer> numeros = new ArrayList<Integer>();
    int mayor = 0;
    int menor = 999999;
    int suma = 0;
    double media;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void guardar(View v){

        EditText et = findViewById(R.id.txtNumero);
        TextView tv = findViewById(R.id.txtResultado);
        numeros.add(Integer.valueOf(String.valueOf(et.getText())));
        tv.setText("");

    }

    public void calcular(View v){

        TextView tv = findViewById(R.id.txtResultado);

        for (int x = 0; x < numeros.size(); x++){

            if (numeros.get(x) > mayor){

                mayor = numeros.get(x);

            }

            if (numeros.get(x) < menor){

                menor = numeros.get(x);

            }

            suma = suma + numeros.get(x);

        }

        tv.setText("Numeros introducidos: " + numeros + "\r \nMayor: " + mayor +
                "\r \nMenor: "+ menor + "\r \nMedia: "+ media);

    }

}