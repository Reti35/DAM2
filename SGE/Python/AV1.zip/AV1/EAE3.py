num = int(input("Introduce un numero : "))
cont = 0

while num > cont:

    print("*" * cont)
    cont = cont + 1

while cont > 0:

    print("*" * cont)
    cont = cont - 1
