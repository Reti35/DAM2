package seccion3;

public class Libro {
	
	String titulo;
	String autor;
	int fechaPublicacion;

}
