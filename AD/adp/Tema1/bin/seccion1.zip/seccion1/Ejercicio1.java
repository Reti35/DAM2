package seccion1;

public class Ejercicio1 {

	public static void main(String[] args) {

		String directorio = args[0];

		System.out.println(directorio);

	}

}
